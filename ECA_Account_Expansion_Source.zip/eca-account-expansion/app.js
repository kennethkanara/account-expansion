(() => {
  const serviceLines = ['Executive Search', 'Interim & Consulting'];
  const accountTypes = ['Lower Middle Market Private Equity', 'Middle Market Private Equity', 'Middle Market Portfolio Company', 'Lower Middle Market Portfolio Company', 'Enterprise', 'Privately Owned', 'Single Family Office', 'Growth Equity', 'Other'];
  const directors = [{id:'d1', name:'Avery Parker'}, {id:'d2', name:'Jordan Lee'}, {id:'d3', name:'Morgan Ellis'}];
  const questionSets = {
    'Executive Search': [
      'Did you visit in person?', 'Did you map the immediate account?', 'Has your client made internal introductions to other relevant stakeholders?',
      'Did you map the relevant adjacencies (e.g., PE firm, portfolio companies, etc.)?', 'Have you introduced Directors from other practice areas?',
      'Have you introduced Directors from another service line?', 'Can you answer the question “What are the main problems my client is trying to solve over the next 12 months?”',
      'Have you given the client a bespoke gift?', 'Have you discussed the account plan with your mentor?'
    ],
    'Interim & Consulting': [
      'Did you visit in person?', 'Did you map the immediate account?', 'Has your client made internal introductions to other relevant stakeholders?',
      'Did you map the relevant adjacencies (e.g., PE firm, portfolio companies, etc.)?', 'Have you introduced Directors from another service line?',
      'Can you answer the question “What are the main problems my client is trying to solve over the next 12 months?”',
      'Have you given the client a bespoke gift?', 'Have you attended regular client and consultant check-ins?', 'Have you discussed the account plan with your mentor?'
    ]
  };
  const blank = () => Array(9).fill(null);
  const demoAccounts = [
    {id:'a1',name:'Northstar Capital',type:'Middle Market Private Equity',service:'Executive Search',lead:'d1',creator:'d1',answers:['yes','no','yes','no','yes','no','yes','na','no'],updatedBy:'Avery Parker'},
    {id:'a2',name:'Canyon Ridge Holdings',type:'Lower Middle Market Private Equity',service:'Interim & Consulting',lead:'d2',creator:'d2',answers:['yes','yes','no','na','yes','yes','no','yes','yes'],updatedBy:'Jordan Lee'},
    {id:'a3',name:'Summit Medical Group',type:'Middle Market Portfolio Company',service:'Executive Search',lead:'d1',creator:'d1',answers:blank(),updatedBy:'Avery Parker'},
    {id:'a4',name:'Juniper Family Office',type:'Single Family Office',service:'Interim & Consulting',lead:'d3',creator:'d3',answers:['yes','yes','yes','yes','yes','yes','yes','yes','yes'],updatedBy:'Morgan Ellis'},
    {id:'a5',name:'Red Mesa Software',type:'Growth Equity',service:'Executive Search',lead:'d2',creator:'d2',answers:['yes','no','na','yes','no','yes','no','no','yes'],updatedBy:'Jordan Lee'},
    {id:'a6',name:'Blue Sky Manufacturing',type:'Privately Owned',service:'Interim & Consulting',lead:'d3',creator:'d3',answers:['na','na','na','na','na','na','na','na','na'],updatedBy:'Morgan Ellis'},
    {id:'a7',name:'Copperline Partners',type:'Other',service:'Executive Search',lead:'d1',creator:'ken',answers:['yes','yes','yes',null,null,null,null,null,null],updatedBy:'Ken Kanara'}
  ];

  const config = window.ECA_CONFIG || {demoMode:true};
  const state = {screen:'Director Overview', currentUser:'d1', profile:null, users:[], accounts:demoAccounts.map(a=>({...a,answers:[...a.answers]})), filter:'All service lines', search:'', selected:null, toast:'', authError:''};
  let auth=null, db=null, functions=null, accountUnsubscribe=null;
  const $ = (sel, root=document) => root.querySelector(sel);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const currentName = () => config.demoMode ? (state.currentUser === 'ken' ? 'Ken Kanara' : (directors.find(x=>x.id===state.currentUser)?.name || 'Director')) : (state.profile?.displayName || state.profile?.email || 'User');
  const isAdmin = () => config.demoMode ? state.currentUser === 'ken' : state.profile?.role === 'admin';
  const leadName = id => config.demoMode ? (directors.find(x=>x.id===id)?.name || 'Ken Kanara') : (state.users.find(x=>x.id===id)?.displayName || state.users.find(x=>x.id===id)?.email || 'Director');
  const people = () => config.demoMode ? directors : state.users.filter(u=>u.role==='director'&&u.active!==false);
  const normalizedAccount = (id,d) => ({id,name:d.name,type:d.type,service:d.primaryServiceLine,lead:d.leadDirectorUid,creator:d.createdBy,other:d.otherDirector||'',answers:d.scorecard?.answers||blank(),updatedBy:d.updatedByName||'—',updatedAt:d.updatedAt?.toDate?.()?.toISOString?.()||null,scoreUpdatedBy:d.scorecard?.lastUpdatedByName||d.updatedByName||'—',scoreUpdatedAt:d.scorecard?.lastUpdatedAt?.toDate?.()?.toISOString?.()||null});
  function score(account) {
    const applicable=account.answers.filter(x=>x!=='na');
    if (!applicable.length && account.answers.every(x=>x==='na')) return {pct:null, status:'All N/A', yes:0, no:0, na:9, answered:9};
    const yes=account.answers.filter(x=>x==='yes').length, no=account.answers.filter(x=>x==='no').length, na=account.answers.filter(x=>x==='na').length;
    const answered=yes+no+na, denominator=9-na;
    if (!answered) return {pct:0,status:'Not started',yes,no,na,answered};
    if (answered < 9) return {pct:denominator ? Math.round(yes/denominator*100) : null,status:'Incomplete',yes,no,na,answered};
    const pct=denominator ? Math.round(yes/denominator*100) : null;
    return {pct,status:pct===null?'All N/A':pct>=87.5?'On track':pct>=65?'Needs attention':'Priority',yes,no,na,answered};
  }
  function average(accounts) {
    const vals=accounts.map(a=>score(a)).filter(s=>s.pct!==null).map(s=>s.pct);
    return vals.length ? Math.round(vals.reduce((a,b)=>a+b,0)/vals.length) : null;
  }
  const scoreLabel = a => {const s=score(a); return s.pct===null?'N/A':`${s.pct}%`;};
  const bandClass = a => {const s=score(a);return s.pct===null?'neutral':s.pct>=87.5?'good':s.pct>=65?'warn':'bad';};
  function nextSteps(a) {
    const actions=a.service==='Executive Search'?
      ['Visit client in person','Map the immediate account','Ask the client for internal introductions to relevant stakeholders','Map relevant adjacencies (e.g., PE firm and portfolio companies)','Introduce Directors from other practice areas','Introduce Directors from another service line','Clarify the client’s main problems to solve over the next 12 months','Give the client a bespoke gift','Discuss the account plan with your mentor']:
      ['Visit client in person','Map the immediate account','Ask the client for internal introductions to relevant stakeholders','Map relevant adjacencies (e.g., PE firm and portfolio companies)','Introduce Directors from another service line','Clarify the client’s main problems to solve over the next 12 months','Give the client a bespoke gift','Attend regular client and consultant check-ins','Discuss the account plan with your mentor'];
    return actions.filter((_,i)=>a.answers[i]==='no');
  }
  function summaryStatus(a) {const s=score(a); return s.status==='Incomplete'?'Incomplete':s.status;}
  function stat(label,value,detail='') {return `<div class="stat"><div class="stat-label">${label}</div><div class="stat-value">${value}</div>${detail?`<div class="stat-detail">${detail}</div>`:''}</div>`;}
  function accountRows(accounts, showOwner=true) {
    if (!accounts.length) return `<div class="empty">No accounts match this view.</div>`;
    return `<div class="table-wrap"><table><thead><tr><th>Account</th><th>Type</th><th>Primary service line</th>${showOwner?'<th>Lead Director</th>':''}<th>Score</th><th>Status</th><th>Next steps</th><th></th></tr></thead><tbody>${accounts.map(a=>{
      const steps=nextSteps(a), shown=steps.slice(0,2), more=steps.length-shown.length;
      const editable=isAdmin()||a.lead===state.currentUser, deletable=a.creator===state.currentUser;
      return `<tr><td><button class="link account-open" data-id="${a.id}">${esc(a.name)}</button></td><td>${esc(a.type)}</td><td>${esc(a.service)}</td>${showOwner?`<td>${esc(leadName(a.lead))}</td>`:''}<td><span class="score ${bandClass(a)}">${scoreLabel(a)}</span></td><td>${esc(summaryStatus(a))}</td><td class="steps">${shown.length?shown.map(x=>`<span>${esc(x)}</span>`).join(''):'<span class="muted">—</span>'}${more>0?`<span class="muted">+${more} more</span>`:''}</td><td class="row-actions"><button class="icon-btn score-open" data-id="${a.id}" aria-label="Open scorecard" title="Open scorecard">▤</button>${editable?`<button class="icon-btn edit-open" data-id="${a.id}" aria-label="Edit account" title="Edit account">✎</button>`:''}${deletable?`<button class="icon-btn delete-open" data-id="${a.id}" aria-label="Delete account" title="Delete account">×</button>`:''}</td></tr>`;
    }).join('')}</tbody></table></div>`;
  }
  function directorOverview() {
    const mine=state.accounts.filter(a=>a.lead===state.currentUser), avg=average(mine), complete=mine.filter(a=>score(a).answered===9).length;
    return `<section class="page-head"><div><div class="eyebrow">ACCOUNT MANAGEMENT</div><h1>Director Overview</h1><p>Track account coverage and turn gaps into next steps.</p></div><div class="head-actions">${isAdmin()?'<button class="secondary" id="invite-director">Invite Director</button>':''}<button class="primary" id="add-account">＋ Add account</button></div></section>
      ${config.demoMode?`<div class="demo-note"><strong>Prototype mode</strong><span>Sample data resets when you reload. The selector below is for testing only; it does not verify identity or restrict access.</span><label>View as <select id="user-switch"><option value="ken" ${state.currentUser==='ken'?'selected':''}>Ken Kanara · Admin</option>${directors.map(d=>`<option value="${d.id}" ${state.currentUser===d.id?'selected':''}>${esc(d.name)} · Director</option>`).join('')}</select></label></div>`:''}
      <div class="stats">${stat('Assigned accounts',mine.length)}${stat('Scorecards completed',`${complete} / ${mine.length}`)}${stat('Average account score',avg===null?'—':`${avg}%`,'All N/A accounts excluded; unstarted accounts count as zero.')}</div>
      <section class="panel"><div class="panel-head"><div><h2>My accounts</h2><p>Accounts assigned to ${esc(currentName())}</p></div><span class="count">${mine.length} accounts</span></div>${accountRows(mine)}</section>`;
  }
  function teamOverview() {
    const avg=average(state.accounts);
    const team=people();
    return `<section class="page-head"><div><div class="eyebrow">TEAM PERFORMANCE</div><h1>Team Overview</h1><p>Compare account coverage and scorecard progress across Directors.</p></div></section>
      <div class="stats">${stat('Directors',team.length)}${stat('Accounts',state.accounts.length)}${stat('Team average',avg===null?'—':`${avg}%`)}</div>
      <section class="panel"><div class="panel-head"><div><h2>Director scorecards</h2><p>Every Director is visible to approved users.</p></div></div><div class="table-wrap"><table><thead><tr><th>Director</th><th>Accounts</th><th>Average score</th><th>Completed</th><th>Accounts</th></tr></thead><tbody>${team.map(d=>{const acc=state.accounts.filter(a=>a.lead===d.id), av=average(acc), complete=acc.filter(a=>score(a).answered===9).length;return `<tr><td><strong>${esc(d.displayName||d.name||d.email)}</strong></td><td>${acc.length}</td><td><span class="score ${av===null?'neutral':av>=87.5?'good':av>=65?'warn':'bad'}">${av===null?'—':`${av}%`}</span></td><td>${complete} / ${acc.length}</td><td>${acc.length?acc.map(a=>`<button class="link account-open" data-id="${a.id}">${esc(a.name)}</button>`).join('<span class="muted"> · </span>'):'—'}</td></tr>`;}).join('')}</tbody></table></div></section>`;
  }
  function allAccounts() {
    const found=state.accounts.filter(a=>(!state.search||a.name.toLowerCase().includes(state.search.toLowerCase()))&&(state.filter==='All service lines'||a.service===state.filter));
    return `<section class="page-head"><div><div class="eyebrow">TEAM PORTFOLIO</div><h1>All Accounts</h1><p>Find account gaps and follow-up actions across ECA.</p></div><button class="primary" id="add-account">＋ Add account</button></section>
      <section class="panel"><div class="toolbar"><label class="search"><span>⌕</span><input id="search" type="search" placeholder="Search account name" value="${esc(state.search)}" aria-label="Search by account name"></label><label class="filter-label">Service line<select id="service-filter"><option>All service lines</option>${serviceLines.map(s=>`<option ${state.filter===s?'selected':''}>${esc(s)}</option>`).join('')}</select></label><span class="count">${found.length} of ${state.accounts.length}</span></div>${accountRows(found)}</section>`;
  }
  function render() {
    const content=state.screen==='Director Overview'?directorOverview():state.screen==='Team Overview'?teamOverview():allAccounts();
    $('#app').innerHTML=`<div class="shell"><aside class="sidebar"><div class="brand"><div class="brand-mark">E</div><div><strong>ECA</strong><span>ACCOUNT EXPANSION</span></div></div><div class="workspace-label">WORKSPACE</div><nav>${['Director Overview','Team Overview','All Accounts'].map((s,i)=>`<button class="nav-item ${state.screen===s?'active':''}" data-screen="${s}"><span class="nav-icon">${['◫','◉','▤'][i]}</span>${s}</button>`).join('')}</nav><div class="side-footer"><div class="avatar">${currentName().split(' ').map(x=>x[0]).join('').slice(0,2)}</div><div><strong>${esc(currentName())}</strong><span>${isAdmin()?'Administrator':'Director'}</span></div><span class="chevron">⌄</span></div></aside><main class="main"><div class="topbar"><div class="crumb">ECA Partners <span>/</span> ${esc(state.screen)}</div><div class="top-right"><span class="mode-pill">${config.demoMode?'DEMO':'FIREBASE'}</span><div class="avatar small">${currentName().split(' ').map(x=>x[0]).join('').slice(0,2)}</div></div></div><div class="content">${content}</div></main></div><div id="modal-root"></div><div id="toast" class="toast ${state.toast?'visible':''}">${esc(state.toast)}</div>`;
    bind();
  }
  function bind() {
    document.querySelectorAll('[data-screen]').forEach(b=>b.onclick=()=>{state.screen=b.dataset.screen;render();});
    $('#user-switch')?.addEventListener('change',e=>{state.currentUser=e.target.value;render();});
    $('#search')?.addEventListener('input',e=>{state.search=e.target.value;const pos=e.target.selectionStart;render();$('#search')?.focus();$('#search')?.setSelectionRange(pos,pos);});
    $('#service-filter')?.addEventListener('change',e=>{state.filter=e.target.value;render();});
    $('#add-account')?.addEventListener('click',()=>accountDialog());
    $('#invite-director')?.addEventListener('click',()=>inviteDialog());
    document.querySelectorAll('.score-open,.account-open').forEach(b=>b.onclick=()=>scoreDialog(b.dataset.id));
    document.querySelectorAll('.edit-open').forEach(b=>b.onclick=()=>accountDialog(b.dataset.id));
    document.querySelectorAll('.delete-open').forEach(b=>b.onclick=()=>deleteAccount(b.dataset.id));
  }
  function showModal(html) {$('#modal-root').innerHTML=`<div class="scrim" id="scrim"><section class="dialog" role="dialog" aria-modal="true">${html}</section></div>`;$('#scrim').addEventListener('click',e=>{if(e.target.id==='scrim')closeModal();});document.querySelectorAll('.dialog-close').forEach(button=>button.addEventListener('click',closeModal));}
  function closeModal(){ $('#modal-root').innerHTML=''; }
  function accountDialog(id=null) {
    const old=state.accounts.find(a=>a.id===id), ownDirector=!isAdmin();
    if(old&&!isAdmin()&&old.lead!==state.currentUser)return;
    const leadChoices=people(), selectedLead=old?.lead||(ownDirector?state.currentUser:leadChoices[0]?.id);
    showModal(`<header class="dialog-head"><div><div class="eyebrow">ACCOUNT DETAILS</div><h2>${old?'Edit account':'Add account'}</h2><p>${old?'Update account information.':'Create an account and assign its Lead Director.'}</p></div><button class="dialog-close" aria-label="Close">×</button></header><form id="account-form" class="form-grid"><label class="span-2">Account name<input name="name" required maxlength="120" value="${esc(old?.name||'')}" placeholder="e.g., Northstar Capital"></label><label class="span-2">Account type<select name="type" required><option value="">Select account type</option>${accountTypes.map(x=>`<option ${old?.type===x?'selected':''}>${esc(x)}</option>`).join('')}</select></label><label>Primary service line<select name="service" required>${serviceLines.map(x=>`<option ${old?.service===x?'selected':''}>${esc(x)}</option>`).join('')}</select></label><label>Lead Director<select name="lead" ${ownDirector?'disabled':''} required>${leadChoices.map(d=>`<option value="${d.id}" ${selectedLead===d.id?'selected':''}>${esc(d.displayName||d.name||d.email)}</option>`).join('')}</select>${ownDirector?`<input type="hidden" name="lead" value="${state.currentUser}">`:''}</label><label class="span-2">Other Director <span class="muted">(optional description only)</span><input name="other" value="${esc(old?.other||'')}" maxlength="120"></label><div class="form-actions span-2"><button type="button" class="secondary dialog-close">Cancel</button><button class="primary" type="submit">Save account</button></div></form>`);
    $('#account-form').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const lead=fd.get('lead'), name=fd.get('name').trim(), type=fd.get('type'), service=fd.get('service'), other=fd.get('other').trim();try{if(config.demoMode){const now=new Date().toISOString();if(old)Object.assign(old,{name,type,service,lead,other,updatedBy:currentName(),updatedAt:now});else state.accounts.unshift({id:`a${Date.now()}`,name,type,service,lead,creator:state.currentUser,other,answers:blank(),updatedBy:currentName(),updatedAt:now});closeModal();notify(old?'Account updated':'Account added');render();}else{const doc={name,type,primaryServiceLine:service,leadDirectorUid:lead,otherDirector:other,updatedBy:auth.currentUser.uid,updatedByName:currentName(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()};if(old){await db.collection('accounts').doc(old.id).update(doc);}else{doc.createdBy=auth.currentUser.uid;doc.createdAt=firebase.firestore.FieldValue.serverTimestamp();doc.scorecard={answers:blank(),lastUpdatedBy:auth.currentUser.uid,lastUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()};await db.collection('accounts').add(doc);}closeModal();notify(old?'Account updated':'Account added');}}catch(err){showError(err.message);}});
  }
  function scoreDialog(id) {
    const a=state.accounts.find(x=>x.id===id);if(!a)return;
    const canEdit=isAdmin()||a.lead===state.currentUser, qs=questionSets[a.service], s=score(a);
    showModal(`<header class="dialog-head"><div><div class="eyebrow">ACCOUNT SCORECARD</div><h2>${esc(a.name)}</h2><p>${esc(a.type)} <span>·</span> ${esc(a.service)} <span>·</span> Lead Director: ${esc(leadName(a.lead))}</p></div><button class="dialog-close" aria-label="Close">×</button></header><div class="score-summary"><div><span class="eyebrow">CURRENT SCORE</span><strong class="big-score">${scoreLabel(a)}</strong></div><div class="score-counts"><span>Yes <b>${s.yes}</b></span><span>No <b>${s.no}</b></span><span>N/A <b>${s.na}</b></span><span>Unanswered <b>${9-s.answered}</b></span></div><span class="score ${bandClass(a)}">${esc(summaryStatus(a))}</span></div><form id="score-form"><div class="question-list">${qs.map((q,i)=>`<fieldset class="question"><legend><span class="q-num">${String(i+1).padStart(2,'0')}</span>${esc(q)}</legend><div class="choices">${[['yes','Yes'],['no','No'],['na','Not applicable']].map(([v,l])=>`<label class="choice ${a.answers[i]===v?'selected':''}"><input type="radio" name="q${i}" value="${v}" ${a.answers[i]===v?'checked':''} ${!canEdit?'disabled':''}><span>${l}</span></label>`).join('')}</div></fieldset>`).join('')}</div><div class="dialog-footer"><span class="muted">Scorecard last updated by ${esc(a.scoreUpdatedBy||a.updatedBy||leadName(a.lead))}${a.scoreUpdatedAt?` · ${new Date(a.scoreUpdatedAt).toLocaleDateString()}`:''}</span><div><button type="button" class="secondary dialog-close">Close</button>${canEdit?'<button class="primary" type="submit">Save scorecard</button>':''}</div></div></form>`);
    if(canEdit){$('#score-form').addEventListener('change',e=>{if(e.target.matches('input[type=radio]'))e.target.closest('.choice').parentElement.querySelectorAll('.choice').forEach(c=>c.classList.toggle('selected',c.contains(e.target)));});$('#score-form').addEventListener('submit',async e=>{e.preventDefault();const answers=[...a.answers];for(let i=0;i<9;i++){const v=new FormData(e.currentTarget).get(`q${i}`);if(v)answers[i]=v;}try{if(config.demoMode){a.answers=answers;a.updatedBy=currentName();a.updatedAt=new Date().toISOString();a.scoreUpdatedBy=currentName();a.scoreUpdatedAt=a.updatedAt;}else{await db.collection('accounts').doc(a.id).update({scorecard:{answers,lastUpdatedBy:auth.currentUser.uid,lastUpdatedByName:currentName(),lastUpdatedAt:firebase.firestore.FieldValue.serverTimestamp()},updatedBy:auth.currentUser.uid,updatedByName:currentName(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});}closeModal();state.screen='Director Overview';notify('Scorecard saved');render();}catch(err){showError(err.message);}});}
  }
  async function deleteAccount(id) {const a=state.accounts.find(x=>x.id===id);if(!a||a.creator!==state.currentUser)return;if(!confirm(`Permanently delete ${a.name}? This cannot be undone.`))return;try{if(config.demoMode)state.accounts=state.accounts.filter(x=>x.id!==id);else await db.collection('accounts').doc(id).delete();notify('Account permanently deleted');render();}catch(err){showError(err.message);}}
  function inviteDialog(){
    showModal(`<header class="dialog-head"><div><div class="eyebrow">TEAM ACCESS</div><h2>Invite a Director</h2><p>They’ll receive a one-time email sign-in link.</p></div><button class="dialog-close" aria-label="Close">×</button></header><form id="invite-form" class="form-grid"><label class="span-2">Director name<input name="displayName" required maxlength="100" autocomplete="name"></label><label class="span-2">Work email<input name="email" type="email" required autocomplete="email"></label><p class="span-2 muted">Invited users can view all three screens. They can edit accounts assigned to them.</p><div class="form-actions span-2"><button type="button" class="secondary dialog-close">Cancel</button><button class="primary" type="submit">Send invitation</button></div></form>`);
    $('#invite-form').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.currentTarget),button=e.currentTarget.querySelector('[type=submit]');button.disabled=true;button.textContent='Sending…';try{if(config.demoMode)throw new Error('Invitations are disabled in the sample-data prototype.');await functions.httpsCallable('sendInvite')({email:fd.get('email'),displayName:fd.get('displayName')});closeModal();notify('Invitation sent');}catch(err){button.disabled=false;button.textContent='Send invitation';showError(err.message);}});
  }
  function showError(message){state.authError=message;const box=$('#form-error');if(box)box.textContent=message;else notify(message||'Something went wrong. Please try again.');}
  function renderLogin(){
    $('#app').innerHTML=`<main class="login-page"><section class="login-card"><div class="brand-mark">E</div><div class="eyebrow">ECA PARTNERS</div><h1>Account Expansion</h1><p>Sign in with your invited work email. We’ll send you a one-time link.</p><form id="login-form"><label>Work email<input name="email" type="email" autocomplete="email" required placeholder="you@company.com"></label><button class="primary" type="submit">Email me a sign-in link</button></form><div id="form-error" class="login-error">${esc(state.authError)}</div><div class="login-foot">Access is limited to invited ECA users.</div></section></main>`;
    $('#login-form').addEventListener('submit',async e=>{e.preventDefault();const email=new FormData(e.currentTarget).get('email').trim();try{await auth.sendSignInLinkToEmail(email,{url:window.location.origin,handleCodeInApp:true});sessionStorage.setItem('ecaSignInEmail',email);state.authError='Check your inbox for your one-time sign-in link.';renderLogin();$('#form-error').classList.add('success');}catch(err){showError(err.message);}});
  }
  function normalizeProfile(doc){return {id:doc.id,...doc.data()};}
  function startFirebase(){
    const f=config.firebase;
    if(!window.firebase||!f?.apiKey||!f?.projectId||!f?.appId){state.authError='Firebase is not configured yet. Copy firebase-config.example.js to firebase-config.js and add your Firebase web app settings.';$('#app').innerHTML=`<main class="login-page"><section class="login-card"><div class="brand-mark">E</div><div class="eyebrow">SETUP REQUIRED</div><h1>Connect your Firebase project</h1><p>${esc(state.authError)}</p></section></main>`;return;}
    try{const app=firebase.initializeApp(f);auth=app.auth();db=app.firestore();functions=app.functions();
      const emailLink=auth.isSignInWithEmailLink(window.location.href);
      const finishLink=async()=>{const email=sessionStorage.getItem('ecaSignInEmail')||window.prompt('Confirm the email address where you received the sign-in link');if(email){try{await auth.signInWithEmailLink(email,window.location.href);sessionStorage.removeItem('ecaSignInEmail');history.replaceState({},document.title,window.location.pathname);}catch(err){state.authError=err.message;renderLogin();}}};
      if(emailLink)finishLink();
      auth.onAuthStateChanged(async user=>{if(accountUnsubscribe){accountUnsubscribe();accountUnsubscribe=null;}if(!user){state.profile=null;state.accounts=[];renderLogin();return;}try{const profile=await db.collection('users').doc(user.uid).get();if(!profile.exists||profile.data().active!==true){await auth.signOut();state.authError='This email is not on the invitation list. Ask Ken for an invitation.';renderLogin();return;}state.profile=normalizeProfile(profile);state.currentUser=user.uid;const userDocs=await db.collection('users').get();state.users=userDocs.docs.map(normalizeProfile);accountUnsubscribe=db.collection('accounts').onSnapshot(snap=>{state.accounts=snap.docs.map(d=>normalizedAccount(d.id,d.data()));render();},err=>{state.authError=err.message;render();});}catch(err){state.authError=err.message;renderLogin();}});
    }catch(err){state.authError=err.message;renderLogin();}
  }
  let toastTimer;
  function notify(message){state.toast=message;render();clearTimeout(toastTimer);toastTimer=setTimeout(()=>{state.toast='';$('#toast')?.classList.remove('visible');},2600);}
  if(config.demoMode)render();else startFirebase();
})();
