# ECA Account Expansion

Source package based on **ECA Account Expansion Business Requirements, Version 1.6**.

## Prototype

The default setup runs in clearly labeled demo mode. It uses fictional sample accounts, does not connect to Firebase, and keeps edits in memory so they reset when the page is reloaded. The Director selector is only a test control; it is not authentication or an access control.

## Firebase setup and deployment

This package contains the app source, Firestore security rules, and invitation function. It is not connected to an ECA Firebase project and has not been deployed. The first run is the resettable demo; Firebase mode requires project configuration below.

1. Create a Firebase project, register a web app, enable Cloud Firestore, and register Firebase Hosting. Install the Firebase CLI, sign in, and select the project for this folder with `firebase use --add`.
2. Copy `firebase-config.example.js` to `firebase-config.js`; enter your web app values and set `demoMode: false`. Firebase's web config identifies the project; authorization is enforced by Auth and Firestore rules.
3. In Firebase Authentication, enable Email link sign-in, authorize the Hosting domain, and disable account creation/deletion by end users. Only users created by the Admin invitation flow should be able to sign in. Confirm this with a test email before inviting the team.
4. Install Cloud Functions dependencies from `functions/` with `npm install`.
5. Create Ken's Auth user, then use a trusted operator session with Firebase Admin credentials to run `node scripts/bootstrap-admin.js <admin-email> "Ken Kanara"` from `functions/`. Never grant Admin from browser code.
6. Cloud Functions deployment requires the Firebase project to be on the Blaze pay-as-you-go plan with billing linked. Review billing implications and set suitable budget alerts before deployment.
7. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `INVITE_FROM` as Cloud Functions secrets. Set the `APP_CONTINUE_URL` function parameter to the deployed app origin and authorize that domain in Firebase Authentication.
8. From this project folder, run `npm run build`, then deploy with `firebase deploy --only hosting,firestore:rules,functions`. Test invite-only sign-in and each role/deletion rule with the Firebase Emulator Suite before using real client data.

Firebase mode implements email-link sign-in, shared Firestore account/scorecard records, Admin invitations, server-enforced access rules, and Admin account reassignment through the account form. `npm run build` creates the static Hosting folder and copies `firebase-config.js` if present; without it, the build uses demo mode. Real Firebase project settings and SMTP credentials are intentionally not included. Prototype mode uses fictional in-memory sample data and resets on reload; it must not be used for confidential account data.

## Files

- `index.html`, `styles.css`, `app.js`: clickable prototype source.
- `firebase.json`, `firestore.rules`: Firebase Hosting and Firestore configuration.
- `functions/`: trusted server-side invitation email function and first-admin bootstrap script. Admin reassignment is allowed by Firestore Rules and the account edit form.
- `firebase-config.example.js`: safe configuration template; do not add real credentials to a shared archive.
