const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const out = path.join(root, 'dist');
fs.rmSync(out, {recursive: true, force: true});
fs.mkdirSync(out, {recursive: true});

for (const name of ['index.html', 'app.js', 'styles.css', 'favicon.svg']) {
  fs.copyFileSync(path.join(root, name), path.join(out, name));
}

const runtimeConfig = path.join(root, 'firebase-config.js');
const demoConfig = path.join(root, 'firebase-config.example.js');
fs.copyFileSync(fs.existsSync(runtimeConfig) ? runtimeConfig : demoConfig, path.join(out, 'firebase-config.js'));
console.log(`Built static app in ${path.relative(root, out)} (${fs.readdirSync(out).length} files).`);
