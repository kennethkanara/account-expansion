// Copy to firebase-config.js and replace the values from your Firebase web app.
// Keep demoMode true for the ChatGPT test prototype. Set false for Firebase.
window.ECA_CONFIG = {
  demoMode: true,
  firebase: {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    appId: "YOUR_APP_ID"
  }
};
