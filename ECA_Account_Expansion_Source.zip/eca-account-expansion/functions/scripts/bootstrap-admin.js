// Run locally from functions/ after authenticating with Firebase Admin ADC.
// Usage: node scripts/bootstrap-admin.js admin@yourcompany.com "Ken Kanara"
const admin = require('firebase-admin');
admin.initializeApp();

async function main() {
  const email = String(process.argv[2] || '').trim().toLowerCase();
  const displayName = String(process.argv[3] || '').trim();
  if (!email || !displayName) throw new Error('Provide the admin email and display name.');
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, {role:'admin'});
  await admin.firestore().doc(`users/${user.uid}`).set({email,displayName,role:'admin',active:true,updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});
  console.log(`Admin access enabled for ${email}.`);
}

main().then(()=>process.exit(0)).catch(error=>{console.error(error);process.exit(1);});
