const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {defineSecret, defineString} = require('firebase-functions/params');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');

admin.initializeApp();
const db = admin.firestore();
const smtpHost = defineSecret('SMTP_HOST');
const smtpPort = defineSecret('SMTP_PORT');
const smtpUser = defineSecret('SMTP_USER');
const smtpPassword = defineSecret('SMTP_PASSWORD');
const sender = defineSecret('INVITE_FROM');
const appContinueUrl = defineString('APP_CONTINUE_URL');

async function requireAdmin(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const doc = await db.doc(`users/${request.auth.uid}`).get();
  if (!doc.exists || doc.data().active !== true || doc.data().role !== 'admin') {
    throw new HttpsError('permission-denied', 'Admin access required.');
  }
}

exports.sendInvite = onCall({secrets: [smtpHost, smtpPort, smtpUser, smtpPassword, sender]}, async (request) => {
  await requireAdmin(request);
  const email = String(request.data?.email || '').trim().toLowerCase();
  const displayName = String(request.data?.displayName || '').trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpsError('invalid-argument', 'Enter a valid email address.');
  if (!displayName) throw new HttpsError('invalid-argument', 'Enter the Director name.');
  let user;
  try { user = await admin.auth().getUserByEmail(email); }
  catch (error) {
    if (error.code !== 'auth/user-not-found') throw error;
    user = await admin.auth().createUser({email, displayName, emailVerified: false, disabled: false});
  }
  const userRef = db.doc(`users/${user.uid}`);
  const existingProfile = await userRef.get();
  if (existingProfile.exists && existingProfile.data().active === true && existingProfile.data().role !== 'director') {
    throw new HttpsError('already-exists', 'This email belongs to a non-Director account.');
  }
  if (user.displayName !== displayName || user.disabled) await admin.auth().updateUser(user.uid, {displayName, disabled: false});
  await admin.auth().setCustomUserClaims(user.uid, {role: 'director'});
  await userRef.set({email, displayName, role: 'director', active: true, invitedBy: request.auth.uid, updatedAt: admin.firestore.FieldValue.serverTimestamp()}, {merge: true});
  const link = await admin.auth().generateSignInWithEmailLink(email, {
    url: appContinueUrl.value(),
    handleCodeInApp: true
  });
  const transport = nodemailer.createTransport({host: smtpHost.value(), port: Number(smtpPort.value()), secure: Number(smtpPort.value()) === 465, auth: {user: smtpUser.value(), pass: smtpPassword.value()}});
  await transport.sendMail({from: sender.value(), to: email, subject: 'Your ECA Account Expansion sign-in link', text: `Hello ${displayName},\n\nUse this one-time link to sign in to ECA Account Expansion:\n\n${link}\n\nIf you did not expect this invitation, you can ignore this email.`});
  return {sent: true};
});
